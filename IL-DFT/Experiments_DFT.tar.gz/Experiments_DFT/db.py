# Import necessary modules
import json
import uuid

# Generating unique identifiers to be used as database entry names
tag1=uuid.uuid4()
tag2=uuid.uuid4()
tag3=uuid.uuid4()

# Parsing the database
json_data=open('db.json')
data=json.load(json_data)
keys = data[0].keys()

# Loop over all fragments
for fragment in ["IP","An","Cat"]:

  # Opening calculation output file
  file = open("SED_CATION_SEDSED_ANION_SED_"+fragment+".out")

  # Creating lists for properties of interest
  Energy_line = []
  Dipole_line = []
  Chelpg_start = []
  Chelpg_end = []
  Time_line = []

  # Going through the output and appending line numbers to the corresponding lists
  # The line numbers indicate where the properties are located in the output file
  for i, line in enumerate(file): 
    if "FINAL SINGLE POINT ENERGY" in line:
      Energy_line.append(i)	
    elif "TOTAL RUN TIME:" in line:
     Time_line.append(i)
    elif "Magnitude (Debye)" in line:
      Dipole_line.append(i)
  file.close()

  # Now reopening the line to fetch the property values
  file = open("SED_CATION_SEDSED_ANION_SED_"+fragment+".out").readlines()
 
  # Final single point energy is the last element of the corresponding line
  Energy = float(file[Energy_line[-1]].split()[-1])

  #Dipole is the last element of the corresponding line
  Dipole = float(file[Dipole_line[-1]].split()[-1])

  #Total time is converted to seconds
  Time_text=file[Time_line[-1]].split()
  Time = int(Time_text[3])*3600*24+int(Time_text[5])*3600+int(Time_text[7])*60+int(Time_text[9])
  
  # Locating the database entry for this species (ionic pair)
  Species_exists=False
  for i in range (len(keys)):
    if "name" in data[0][keys[i]]:
      if data[0][keys[i]]["name"] == "SED_CATION_SEDSED_ANION_SED":
        Species_exists=True
        species = (keys[i])
        break

  # Creating a new entry if there is none for this species
  if not Species_exists:
    data[0][str(tag1)] = {"name": "SED_CATION_SEDSED_ANION_SED", "cation": "SED_CATION_SED", "anion": "SED_ANION_SED"}
    species = str(tag1)
    json_data.close()

    # Rewriting the database and reparsing the new database
    compILe=open('db.json', 'w+')
    compILe.write(json.dumps(data, indent=2))
  json_data.close() 
  json_data=open('db.json')
  keys = data[0].keys()

  # Locating the database entry for this computational method
  Method_exists=False
  for j in range (len(keys)):
    if "functional" in data[0][keys[j]]:
      if data[0][keys[j]]["functional"] == "SED_FUNCTIONAL_SED":
        if data[0][keys[j]]["basis_set"] == "SED_BASISSET_SED":
          Method_exists=True
          method = (keys[j])
          break

  # Creating a new entry if there is none for this method
  if not Method_exists:
    data[0][str(tag2)] = {"version": "SED_VERSION_SED", "functional": "SED_FUNCTIONAL_SED", "basis_set": "SED_BASISSET_SED"}
    method = str(tag2)
    json_data.close()

    # Rewriting the database and reparsing the new database
    compILe=open('db.json', 'w+')
    compILe.write(json.dumps(data, indent=2))
  json_data.close() 
  json_data=open('db.json')
  keys = data[0].keys()

  # Now that the species and method entries are known, the results are indexed in the database
  # For results, a new entry is created, which is linked to the entries that contain info on the method and the species
  # This way the information about the species and the method are not repeated, while they are still linked to results
 
  # As tag3 is constant throughout this loop, all fragment results are compiled into the same entry
  # If tag3 exists, new property:value pairs are added. If not then new entry is created.
  # Energies are transfered from Ha into kJ/mol with factor 2625.5
  if str(tag3) in keys:
    data[0][str(tag3)].update({"energy_"+fragment: Energy*2625.5, "dipole_"+fragment: Dipole, "time_"+fragment: Time})
  else:
    data[0][str(tag3)] = {"species": species, "method": method, "energy_"+fragment: Energy*2625.5, "dipole_"+fragment: Dipole, "time_"+fragment: Time}

  # The database is rewritten and reparesed
  json_data.close()
  compILe=open('db.json', 'w+')
  compILe.write(json.dumps(data, indent=2))
  json_data.close() 
  json_data=open('db.json')
  keys = data[0].keys()

# After all fragment properties are gathered in the database, derivative operations can be done
# For example, interaction energies of the ionic pairs are calculated Eint=E(IP)-E(An)-E(Cat)
# First re-reading the database
json_data.close() 
json_data=open('db.json')
keys = data[0].keys()

# Calculating and adding a new property "energy_Eint" to the database
if "energy_IP" in data[0][str(tag3)] and "energy_An" in data[0][str(tag3)] and "energy_Cat" in data[0][str(tag3)]:
  E_int=data[0][str(tag3)]["energy_IP"]-data[0][str(tag3)]["energy_An"]-data[0][str(tag3)]["energy_Cat"]
  data[0][str(tag3)]["energy_Eint"]=E_int

  # Rewriting the database
  json_data.close()
  compILe=open('db.json', 'w+')
  compILe.write(json.dumps(data, indent=2))

# All done
